char * readFileLine(char * file,int lineNumber);
int loadSMLCode(char * file ,int  code[][5]);