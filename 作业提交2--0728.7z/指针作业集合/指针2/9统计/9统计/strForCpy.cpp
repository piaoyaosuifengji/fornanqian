#include "strForCpy.h"
#include <iostream>
using namespace std;
strForCpy::strForCpy(int n )
{

	char input[200]={0};
	int i;
	int tmp;
	str=NULL;
	printf("�Ӽ��������볤�Ȳ�����20�ַ��� \n");
	char c=-1;
	for(i=0;;i++)
	{

		scanf("%c",&c);
		if(c == 10)
		{
			break;
		}
		input[i]=c;
		//check(input);
		//
		//tmp=strlen(input);
		//if(tmp>20 || tmp <0)
		//{
		//	cout<<"wrong string,input again"<<"\n";
		//	i--;
		//	continue;
		//}
		//else
		//	break;
	}
	setstr( input);
	//outPutStr();

	//int len=findEnd(str);

}
strForCpy::strForCpy(void)
{
	printf("�Ӽ��������볤�Ȳ�����20�ַ��� \n");
	

	//=new strForCpy;

	char input[200]={0};
	int i;
	int tmp;
	str=NULL;
	for(i=0;;i++)
	{

		cin>>input;

		//check(input);
		//
		tmp=strlen(input);
		if(tmp>20 || tmp <0)
		{
			cout<<"wrong string,input again"<<"\n";
			i--;
			continue;
		}
		else
			break;
	}
	setstr( input);
	//outPutStr();

	//int len=findEnd(str);
}
strForCpy::strForCpy(char * input)
{
	str=NULL;
	int len=findEnd(input);
	if(len >0)
		str=(char *)malloc(sizeof(char)*(len+1));

	strcpy(str,input);
	//cout<<"class strForCpy created  \n";
	//outPutStr();

}
void strForCpy::setstr(class strForCpy * input)
{
	if(str !=NULL)
	{
		free(str);
		str=NULL;
	}
	int len=input->getlen();
	if(len >0)
		str=(char *)malloc(sizeof(char)*(len+1));
	input->copyStr(str);
	//strcpy(str,input);
}
void strForCpy::copyStr(char * output)
{
	if(str !=NULL && output!=NULL)
	{

		strcpy(output,str);

	}

}

int strForCpy::getlen()
{
	int len=findEnd(this->str);
	return len;
}
void strForCpy::setstr(char * input)
{

	if(str !=NULL)
	{
		free(str);
		str=NULL;
	}
	int len=findEnd(input);
	if(len >0)
		str=(char *)malloc(sizeof(char)*(len+1));

	strcpy(str,input);
}
void strForCpy::outPutStr()
{
	printf("%s \n",str);
}
strForCpy::~strForCpy(void)
{
	//printf("strForCpy  ���������� \n");
	if(str)
		free(str);

}
	
char *  strForCpy::getStr(int len)
{
	printf("������һ��������%d���ַ����ַ��� \n",len);
	char *s=(char *)malloc(sizeof(char)*(len+1));
	scanf("%s",s);
	//printf("��������ַ���Ϊ��%s \n",s);
	return s;
	//return NULL;
}

char strForCpy::getChar(int pos)
{
	char c=0;
	int len=findEnd(str);
	if(len >0  && pos <(len) )
	{
	if(pos<len && pos>=0)
		c=str[pos];

	}
	else
		return -1;
		return  c;
}

int strForCpy::compare(class strForCpy *otherstr)//�Ƚ��ַ�����С
{
	int res=0;
	if(otherstr)
	{	
		unsigned char c1, c2;
		int i=0;
		do
		{
			c1 = (unsigned char) this->getChar(i);
			c2 = (unsigned char) otherstr->getChar(i);
			i++;

			if (c1 == '\0')
			{
				res= c1 - c2;
				break;
			}
		}
		while (c1 == c2);

		res= c1 - c2;

		if(res>0)
			res=1;
	}
	return res;
}
 char *  strForCpy::cpoyChars(char * dest,char * src,int len,int start)//��src��start������len���ַ���dest��
{
	int i;
	int j=0;
	for(i=start;i<(start+len);i++)
	{

		dest[j++]=src[i];
	}

	return NULL;
}
void strForCpy::moveStr(int m,char *s)//m��1��ʼ
{

	char front[50];
	char back[50];

	int len=strlen(s);
	int start;
	int num;
	

	start=m;
	num=len-m;
	cpoyChars(front,s,num,start);
	front[num]='\0';
	start=0;
	num=m;
	cpoyChars(back,s,num,start);
	back[num]='\0';
	
	strcat(front,back);
	strcpy(s,front);
}
void strForCpy::outpuMoveStr()
{
	printf("Please input intercept point:");
	int m;
	scanf("%d",&m);
	while(m<1 )
	{
		cout<<"wrong input,input again  \n";
		scanf("%d",&m);
	}
	moveStr( m,str);
	cout<<"after  move:  \n";
	this->outPutStr();
}
void strForCpy::statistics(char *s,int * alphabet,int * space,int *digital)
{
	char c=-1;
	char countAlphabet=0;
	char countSpace=0;
	char countDigital=0;
	int i=0;
	while(c != '\n' && c!='\0')
	{
		c=s[i++];
		if(c == ' ')
			countSpace++;
		if( (c >= '0') && (c<='9'))
			countDigital++;
		if( (c >= 'a') && (c<='z'))
			countAlphabet++;
		if( (c >= 'A') && (c<='Z'))
			countAlphabet++;

	}
	* alphabet=countAlphabet;
	* space=countSpace;
	* digital=countDigital;

}
void strForCpy::outpuStatistics()
{
	//char s[300];
	int countAlphabet, countSpace,countDigital;

	//printf("������һ���ַ� \n");
	//cin>>s;
	//cout<<str<<"\n";
	statistics(str,&countAlphabet,&countSpace,&countDigital);

	printf("Result is:char=%d,num=%d,space=%d\n",countAlphabet,countDigital, countSpace);


}