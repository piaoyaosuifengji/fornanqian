#pragma once
#include "strForCpy.h"
class mystrings
{

private :
	class strForCpy *strs;
	class strForCpy **strsForSort;
	 int count;

	 int findMaxStr(strForCpy *strs, int count);
	 void sort();
	 void insert(class strForCpy *a,class strForCpy *b);
	 void  getStrByIndex(class strForCpy *str,int index,char *s);
	 void check(char *);
public:
	mystrings(void);
	~mystrings(void);
	mystrings(int n);
	void outputMaxStr();
	void output();
	void outputSort();
	void outputInsert();

};

