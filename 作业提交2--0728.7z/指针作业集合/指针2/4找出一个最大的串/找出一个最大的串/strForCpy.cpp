#include "strForCpy.h"
#include <iostream>
using namespace std;

strForCpy::strForCpy(void)
{
	str=NULL;
	//int len=findEnd(input);
	//if(len >0)
	//	str=(char *)malloc(sizeof(char)*(len+1));

	//strcpy(str,input);
}
strForCpy::strForCpy(char * input)
{
	str=NULL;
	int len=findEnd(input);
	if(len >0)
		str=(char *)malloc(sizeof(char)*(len+1));

	strcpy(str,input);
	//cout<<"class strForCpy created  \n";
	//outPutStr();

}
void strForCpy::setstr(char * input)
{

	if(str !=NULL)
	{
		free(str);
		str=NULL;
	}
	int len=findEnd(input);
	if(len >0)
		str=(char *)malloc(sizeof(char)*(len+1));

	strcpy(str,input);
}
void strForCpy::outPutStr()
{
	printf("%s \n",str);
}
strForCpy::~strForCpy(void)
{
	//printf("strForCpy  ���������� \n");
	if(str)
		free(str);

}
	
char *  strForCpy::getStr(int len)
{
	printf("������һ��������%d���ַ����ַ��� \n",len);
	char *s=(char *)malloc(sizeof(char)*(len+1));
	scanf("%s",s);
	//printf("��������ַ���Ϊ��%s \n",s);
	return s;
	//return NULL;
}

char strForCpy::getChar(int pos)
{
	char c=0;
	int len=findEnd(str);
	if(len >0)
	{
	if(pos<len && pos>=0)
		c=str[pos];

	}
		return  c;
}

int strForCpy::compare(class strForCpy *otherstr)//�Ƚ��ַ�����С
{
	int res=0;
	if(otherstr)
	{	
		unsigned char c1, c2;
		int i=0;
		do
		{
			c1 = (unsigned char) this->getChar(i);
			c2 = (unsigned char) otherstr->getChar(i);
			i++;

			if (c1 == '\0')
			{
				res= c1 - c2;
				break;
			}
		}
		while (c1 == c2);

		res= c1 - c2;

		if(res>0)
			res=1;
	}
	return res;
}