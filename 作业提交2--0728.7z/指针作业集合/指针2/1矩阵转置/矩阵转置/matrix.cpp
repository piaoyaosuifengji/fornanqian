#include "matrix.h"

#include <iostream>
using std::string;
matrix::matrix(void):row(0),column(0)
{
}
matrix::matrix(int r,int c):row(r),column(c)
{
	 //row=r;
	 //column=c;
	createMatrix( row,column);
	init();
}

matrix::~matrix(void)
{
	if(data)
	{
		int i;
		for(i=0;i<row;i++)
		{
			if(data[i])
				free(data[i]);
		}
		free(data);
	}
}
void matrix::print()
{
	int i,j;
	printf("��ǰ�������£� \n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
		{

			printf("%2d ",(data[i][j]));
		}
		printf("\n");
	}

}

void matrix::createMatrix(int r,int c)
{
	int i;
	data=(int **)malloc(sizeof(int)*r);
	for(i=0;i<r;i++)
	{
		data[i]=(int *)malloc(sizeof(int)*c);

	}


}
void matrix::init()
{
	int i,j;
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
		{

			(data[i][j])=rand()%100;
		}
		printf("\n");
	}
}
void matrix::printTranspose()
{
	transpose(data, row,column);
	int i,j;
	printf("ת�þ������� \n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
		{

			printf("%2d ",(data[i][j]));
		}
		printf("\n");
	}
}
void matrix::transpose(int **data,const int row,const int column)
{
	int i;
	int ** newmatrix=(int **)malloc(sizeof(int)*row);
	for(i=0;i<row;i++)
	{
		newmatrix[i]=(int *)malloc(sizeof(int)*column);

	}
	for(int i = 0;i < row;i ++){
	   for(int j = 0;j < column;j ++)
	   {
			newmatrix[i][j] = data[j][i];
	   }
	}
	for(int i = 0;i < row;i ++){
	   for(int j = 0;j < column;j ++)
	   {
			data[i][j] = newmatrix[i][j];
	   }
	}

	if(newmatrix)
	{
		int i;
		for(i=0;i<row;i++)
		{
			if(newmatrix[i])
				free(newmatrix[i]);
		}
		free(newmatrix);
	}
}