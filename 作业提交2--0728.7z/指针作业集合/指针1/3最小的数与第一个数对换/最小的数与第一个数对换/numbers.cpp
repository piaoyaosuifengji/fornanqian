#include "numbers.h"

#include <iostream>
using std::string;
numbers::numbers(void)
{

	printf("Input 10 numbers: \n");

	data=(int *)malloc(sizeof(int)*(10));
	count=0;
	while(count<10)
	{
	scanf("%d",data+count);
	count++;
	}
	//outputNumbers();

}
void numbers::outputNumbers(void)
{
	int i;
	printf("Output 10 datas:");
	for(i=0;i<count;i++)
	{
		printf("%d ",*(data+i));

	}
	printf("\n");
}

numbers::~numbers(void)
{
	if(data)
		free(data);

}
//��������Ϊʵ�Σ�ָ����Ϊ�βΣ����ֵ���±����β�����ָ�����ʽ����
void numbers::search(int *pa,int n,int *pmax,int *pflag)
{
	int flag=0;
	int max=*pa;
	int i;
	for(i=0;i<n;i++)
	{
		if((*(pa+i))>max)
		{
			 flag=i;
			 max=*(pa+i);
		}

	}
	*pmax=max;
	 *pflag=flag;
}

void numbers::outputMax(void)
{
	int pmax;
	int pflag;
	search(data,count,&pmax,&pflag);

	printf("Max is:%d\n",pmax);
	printf("Max position is:%d\n",pflag);


}
void numbers::exchange(int a,int b)//����Ӧλ�õ�ֵ����
{
	if(a<0 || b<0 || a>=count || b>=count)
	{
		printf("wrong a,b\n");
		return;
	}
	int tmp;
	tmp=*(data+a);

	*(data+a)=*(data+b);
	*(data+b)=tmp;
}
void numbers::exchange(int *pa,int n)//��������С�������һ�����Ի��������������һ�����Ի�
{
	int max;
	int maxPoint;
	int min;
	int minPoint;

	int i;
	for(i=0;i<n;i++)
	{
		if(i== 0)
		{
			 max=*(pa+i);
			 maxPoint=i;
			 min=*(pa+i);
			 minPoint=i;
		}
		else
		{
			if(max< *(pa+i))
			{
				max=*(pa+i);
				maxPoint=i;
			}
			if(min> *(pa+i))
			{
				min=*(pa+i);
				minPoint=i;
			}
		}

	}	
	//
	if(max != min)
	{	
		if(minPoint == maxPoint)
		{

		}
		else
		{
			if(maxPoint != 0)
				exchange(0,minPoint);
			else
			{
				maxPoint=minPoint;
				exchange(0,minPoint);
			}
			exchange(count-1,maxPoint);
		}

	}


}
void numbers::outputExchange(void)
{


	exchange(data,count);
	outputNumbers();
}