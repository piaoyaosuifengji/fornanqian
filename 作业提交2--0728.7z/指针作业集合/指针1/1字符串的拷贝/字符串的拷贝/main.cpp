

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "strForCpy.h"

void main()
{
	char * inputStr;
	
	inputStr=strForCpy::getStr(100);
	printf("��������ַ���Ϊ��%s \n",inputStr);
	

	class strForCpy  str(inputStr);
	printf("end here \n");
}