

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "strForCpy.h"
void lin()
{

}
void main()
{
	char * inputStr;
	
	inputStr=strForCpy::getStr(100);
	//class strForCpy  str(inputStr);

	int len=strForCpy::getStrLen(inputStr);
	printf("�����ַ�������Ϊ��%d \n",len);

	printf("end here \n");
}