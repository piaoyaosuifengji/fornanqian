#include "numbers.h"

#include <iostream>
using std::string;
numbers::numbers(void)
{

	printf("Input 10 numbers: \n");

	data=(int *)malloc(sizeof(char)*(10));
	count=0;
	while(count<10)
	{
	scanf("%d",data+count);
	count++;
	}
	outputNumbers();

}
void numbers::outputNumbers(void)
{
	int i;
	printf("outputNumbers:\n");
	for(i=0;i<count;i++)
	{
		printf("%d ",*(data+i));

	}
	printf("\n");
}

numbers::~numbers(void)
{
	if(data)
		free(data);

}
//��������Ϊʵ�Σ�ָ����Ϊ�βΣ����ֵ���±����β�����ָ�����ʽ����
void numbers::search(int *pa,int n,int *pmax,int *pflag)
{
	int flag=0;
	int max=*pa;
	int i;
	for(i=0;i<n;i++)
	{
		if((*(pa+i))>max)
		{
			 flag=i;
			 max=*(pa+i);
		}

	}
	*pmax=max;
	 *pflag=flag;
}

void numbers::outputMax(void)
{
	int pmax;
	int pflag;
	search(data,count,&pmax,&pflag);

	printf("Max is:%d\n",pmax);	printf("Max position is:%d\n",pflag);

}