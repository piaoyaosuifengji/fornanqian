//#pragma once
#ifndef BATTLE_H
#define BATTLE_H
#include "battlefieldMap.h"
#include "army.h"
//void battle(MAP *map,ARMY *,ARMY *);
//
//void armyAttack(MAP *map,ARMY *seft,ARMY *target);
//
//int isOver(MAP *map,ARMY *seft,ARMY *target);

#endif BATTLE_H