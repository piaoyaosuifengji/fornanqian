#include "Point2.h"




Point2	subPoint2(Point2  a,Point2 b)
{

	Point2 res;
	res.x=a.x-b.x;
	res.y=a.y-b.y;
	return res;
}