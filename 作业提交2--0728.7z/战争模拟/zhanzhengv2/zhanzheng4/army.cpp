//#include "soldier.h"
#include "army.h"
//#include "battlefieldMap.h"
#include <malloc.h>
#include <stdio.h>

void armyInit(ARMY *army,int armsTypeCounts,int *armsTypes,soldier * soldiers,int armyType)
{
	army->armyType=armyType;
	//�ȷ���armsType���飬����������ֵ�������
	army->armsType=(int *)malloc(sizeof(int)*armsTypeCounts);

	int i;
	for(i=0;i<armsTypeCounts;i++)
	{

		(army->armsType)[i]=armsTypes[i];
	}

	army->armsTypeCount=armsTypeCounts;

	//����ÿ��ʿ�������ڴ�
	army->arms=(void * *)malloc(sizeof(soldier *)*(army->armsTypeCount));
	for(i=0;i<(army->armsTypeCount);i++)
	{
		
		(army->arms)[i]=(void  *)malloc(sizeof(soldier )*((army->armsType)[i]));
	}

	//��ʼ��ÿ��ʿ��

	int j;
	soldier *tmp;
	soldier ** sp=(soldier **)(army->arms);
	for(i=0;i<(army->armsTypeCount);i++)
	{
		for(j=0;j<((army->armsType)[i]);j++)
		{
			tmp=(soldier *)( *(sp+i)+j  );
			setSoldier2(tmp,soldiers+i );
		}

	}

	//printArmyMsg( army);
}
void printArmyMsg(ARMY *army)
{
	int j,i;
	soldier *tmp;
	soldier ** sp=(soldier **)(army->arms);

	if(army->armyType ==1)
		printf("������Ϣ�� : \n");
	else
		printf("�췽��Ϣ�� : \n");
	for(i=0;i<(army->armsTypeCount);i++)
	{
		printf("ʿ�����ͣ� %d: \n",i);
		for(j=0;j<((army->armsType)[i]);j++)
		{
			tmp=(soldier *)( *(sp+i)+j  );
			printsoldierMsg(tmp);
		}
		
	}
}

soldier * getSoldier(ARMY * army,int armsType,int index)
{

	soldier *tmp=NULL;
	soldier ** sp=(soldier **)(army->arms);

	if(armsType<(army->armsTypeCount) && index<(army->armsType)[armsType] )
			tmp=(soldier *)( *(sp+armsType)+index  );

	return tmp;


}
soldier * searchNearEnemySoldier(MAP *map,ARMY *seft,struct Point2 startPos ,ARMY *target)
{
	soldier *tmp;
	struct Point2 pos=startPos;
	struct Point2 nearPos;
	int flagOfStart=seft->armyType;
	soldier * nearest=NULL;
	soldier * near;
	//��pos�㿪ʼ�������ܣ��ҵ�map��flag����0��flagOfStart�ĵ�
	int distance=0;
	int distanceMix=0;
	int i,j;
	for(i=0;i<target->armsTypeCount;i++)
	{
		for(j=0;j<(target->armsType[i]);j++)
		{
			near=getSoldier(target,i,j);
			nearPos=near->pos;
			if(near->HP >0)
			{
				if(nearest == NULL  )
				{
					nearest=near;
					distanceMix=(nearPos.x-pos.x)*(nearPos.x-pos.x)+(nearPos.y-pos.y)*(nearPos.y-pos.y);
				}
				else
				{
					distance=(nearPos.x-pos.x)*(nearPos.x-pos.x)+(nearPos.y-pos.y)*(nearPos.y-pos.y);
					if(distance <distanceMix)
					{
						nearest=near;
						distanceMix=distance;
					}
				}
			}
			
		}

	}

	return nearest;
}

int countSoldier(ARMY *seft)
{
	soldier *tmp;
	soldier * near;
	//��pos�㿪ʼ�������ܣ��ҵ�map��flag����0��flagOfStart�ĵ�
	int distance=0;
	int distanceMix=0;
	int i,j;
	int count=0;
	for(i=0;i<seft->armsTypeCount;i++)
	{
		for(j=0;j<(seft->armsType[i]);j++)
		{
			near=getSoldier(seft,i,j);

			if(near->HP>0)
				count++;

		}



	}

	return count;
}