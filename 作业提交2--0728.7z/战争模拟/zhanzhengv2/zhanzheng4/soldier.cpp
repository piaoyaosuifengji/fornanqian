#include "soldier.h"
#include "army.h"
#include <stdio.h>

void setSoldier(soldier * s,int hp,int attacks,int distances,Point2 pos,int types )
{
	 s->HP=hp;
	 s->attack=attacks;
	 s->distance=distances;
	 s->type=types;
	 s->pos.x=pos.x;
	 s->pos.y=pos.y;
	 s->attackIng=0;
}
void setSoldier2(soldier * to,soldier * from )
{

	setSoldier(to,from->HP,from->attack,from->distance,from->pos,from->type );
}
void printsoldierMsg(soldier *  ss)
{

#define DEBUG  1	
#ifdef DEBUG
	if(ss->HP >0)
	printf("	����=%d,Ѫ��HP=%d,���꣨%d,%d ��",ss->type,ss->HP,ss->pos.x,ss->pos.y);
	if(ss->attackIng ==1 && ss->HP >0)
		printf("�����ڹ������꣨%d,%d �����ĵо�ʿ��\n",ss->attackIngPos.x,ss->attackIngPos.y);
	else
		printf("\n");
#else
	printf("	type=%d,distance=%d,attack=%d,HP=%d,x=%d,y=%d \n",ss->type,ss->distance,ss->attack,ss->HP,ss->pos.x,ss->pos.y);
#endif

}
void setSoldierPos(soldier * to,Point2 pos )
{
	to->pos.x=pos.x;
	to->pos.y=pos.y;
}

int attackSoldier(soldier *self,soldier * enemysoldier)
{
	enemysoldier->HP=enemysoldier->HP-self->attack;


	if(enemysoldier->HP<=0)
	{
		
		enemysoldier->HP=0;
		return 1;
	}
	else
		return 0;


}
int ifCouldAttack(soldier *self,soldier * enemysoldier)
{

	int res=0;
	int distance;
	int Attackdistance;
	if(enemysoldier->HP <=0)
		return 0;
	distance=(self->pos.x-enemysoldier->pos.x)*(self->pos.x-enemysoldier->pos.x)+(self->pos.y-enemysoldier->pos.y)*(self->pos.y-enemysoldier->pos.y);
	Attackdistance=self->distance  * self->distance;
	if(Attackdistance   >= distance)//��������
		return 1;

	return 0;
}
void movesoldier(MAP *map,soldier *self,Point2 pos)//x�Ǻᣬy����
{
	Point2 tmp;
	tmp.y=self->pos.x;
	tmp.x=self->pos.y;
	setMapcontent(map, tmp,0);
	(self->pos.x)=pos.x;
	(self->pos.y)=pos.y;
	tmp.y=self->pos.x;
	tmp.x=self->pos.y;
	setMapcontent(map,tmp,self->HP);//flag=0ʱ��ʾ���ø�λ��Ϊ��
}
  int  findPosCouldMove(MAP *map,soldier *self,int tactics,Point2 *result)
{
	int i,j,res;
	Point2 pos;
	switch(tactics)
	{
	case 1://�����ƶ�
		for(i=1;i<=self->distance;i++)
			{
				pos.x=self->pos.y-i;
				pos.y=self->pos.x;
				res=ifCouldMove(map, pos);
				if(res ==1)
				{
					(*result).y=pos.x;
					(*result).x=pos.y;
					return 1;

				}
			}
			break;
	case 2://�����ƶ�
		for(i=1;i<=self->distance;i++)
			{
				pos.y=self->pos.x;
				pos.x=self->pos.y+i;
				res=ifCouldMove(map, pos);
				if(res ==1)
				{
					(*result).y=pos.x;
					(*result).x=pos.y;
					return 1;

				}
			}
			break;

	default:
		break;
	}

	result=NULL;
	return 0;

}
int  findWayMoveToPos(MAP *map,soldier *self,int tactics,Point2 *result,Point2 *target)
{
	//һ���㵽��һ�����λ�ƿ�������������ʾ
	Point2 moveVector=subPoint2(*target,(self->pos));
	Point2 model;
	

	int i,j,res;
	Point2 pos;

	if(moveVector.x >0)
		model.x=1;
	else if(moveVector.x ==0)
		model.x=0;
	else
		model.x=-1;
	if(moveVector.y >0)
		model.y=1;
	else if(moveVector.y ==0)
		model.y=0;
	else
		model.y=-1;

	switch(tactics)
	{
	case 1://�����ƶ�
	case 2://�����ƶ�
		//�����ж����᷽�����Ƿ���·���ߣ�����x���䡣y��
				if(model.y != 0)
				{
					pos.y=self->pos.x;
					pos.x=self->pos.y +model.y;
					res=ifCouldMove(map, pos);
					if(res ==1)
					{
						(*result).y=pos.x;
						(*result).x=pos.y;
						return 1;

					}
				}
				if(model.x != 0)
				{
					pos.y=self->pos.x +model.x;
					pos.x=self->pos.y;
					res=ifCouldMove(map, pos);
					if(res ==1)
					{
						(*result).y=pos.x;
						(*result).x=pos.y;
						return 1;

					}
				}				


			break;

	default:
		break;
	}

	result=NULL;
	return 0;
}


  int soldierIsHere(MAP *map,ARMY *seft,struct Point2 pos)//�ж�pos���ĵ��ǲ���seft�ı�
  {

	int i,j;
	soldier * tmp;
	for(i=0;i<seft->armsTypeCount;i++)
	{
		for(j=0;j<(seft->armsType[i]);j++)
		{
			tmp= getSoldier(seft,i,j);
			if(tmp->pos.x == pos.x  && tmp->pos.y == pos.y && tmp->HP>0 )//���С�������Ͳ����ڴ�
				return 1;
		}

	}

	  return 0;
  }