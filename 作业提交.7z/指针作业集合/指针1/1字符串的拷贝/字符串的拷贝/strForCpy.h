#pragma once
#include "mystr.h"
class strForCpy :
	public mystr
{
private :
	char *str;

public:
	strForCpy(void);
	strForCpy(char *);
	void outPutStr();
	~strForCpy(void);
	 static char *  getStr(int len);
};

