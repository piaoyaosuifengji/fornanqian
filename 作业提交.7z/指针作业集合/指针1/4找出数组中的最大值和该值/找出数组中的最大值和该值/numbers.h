#pragma once
class numbers
{

private:
	int *data;
	int count;
	void search(int *pa,int n,int *pmax,int *pflag);
public:
	numbers(void);
	
	void outputNumbers(void);
	~numbers(void);
	void outputMax(void);
	 
};

