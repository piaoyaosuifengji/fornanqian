#include "matrix.h"

#include <iostream>
using std::string;
matrix::matrix(void):row(0),column(0)
{
}
matrix::matrix(int r,int c):row(r),column(c)
{
	 //row=r;
	 //column=c;
	createMatrix( row,column);
	init();
}

matrix::~matrix(void)
{
	if(data)
	{
		int i;
		for(i=0;i<row;i++)
		{
			if(data[i])
				free(data[i]);
		}
		free(data);
	}
}
void matrix::print()
{
	int i,j;
	printf("��ǰ�������£� \n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
		{

			printf("%2d ",(data[i][j]));
		}
		printf("\n");
	}

}

void matrix::createMatrix(int r,int c)
{
	int i;
	data=(int **)malloc(sizeof(int)*r);
	for(i=0;i<r;i++)
	{
		data[i]=(int *)malloc(sizeof(int)*c);

	}


}
void matrix::init()
{
	int i,j;
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
		{

			(data[i][j])=rand()%100;
		}
		printf("\n");
	}
}
void matrix::printTranspose()
{
	transpose(data, row,column);
	int i,j;
	printf("ת�þ������� \n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
		{

			printf("%2d ",(data[i][j]));
		}
		printf("\n");
	}
}
void matrix::transpose(int **data,const int row,const int column)
{
	int i;
	int ** newmatrix=(int **)malloc(sizeof(int)*row);
	for(i=0;i<row;i++)
	{
		newmatrix[i]=(int *)malloc(sizeof(int)*column);

	}
	for(int i = 0;i < row;i ++){
	   for(int j = 0;j < column;j ++)
	   {
			newmatrix[i][j] = data[j][i];
	   }
	}
	for(int i = 0;i < row;i ++){
	   for(int j = 0;j < column;j ++)
	   {
			data[i][j] = newmatrix[i][j];
	   }
	}

	if(newmatrix)
	{
		int i;
		for(i=0;i<row;i++)
		{
			if(newmatrix[i])
				free(newmatrix[i]);
		}
		free(newmatrix);
	}
}
int matrix::ColumnSum(int * d,int row)
{
	int sum=0;
	int i;
	for(i=0;i<row;i++)
	{
		sum+=d[i];

	}
	return sum;
}
void matrix::printColumnSum()
{

	int i;
	for(i=0;i<row;i++)
	{
		printf("��%d�еĺ�Ϊ%d\n",i,ColumnSum(data[i],column));

	}


}
void matrix::FindMax(int **p, int m, int n, int *pRow, int *pCol)
{
	int max=p[0][0];
	int maxPointX=0;
	int maxPointY=0;
	int i,j;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{

			if(max<p[i][j])
			{
				max=p[i][j];
				 maxPointX=i;
				 maxPointY=j;
			}
		}

	}
	*pRow=maxPointX;
	*pCol=maxPointY;
}
void matrix::printMax()
{
	int pRow,  pCol;
	//printf("\n****array****\n");
	FindMax(data, row,column,  &pRow,  &pCol);
	printf("\nMax=%d, Row=%d, Col=%d\n",data[pRow][pCol],pRow,pCol);
}