#pragma once
class matrix
{

	int **data;

	const int row;
	const int column;
	 void createMatrix(int r,int c);
	 void init();
	 void transpose(int **data,const int row,const int column);
	 int ColumnSum(int * d,int len);
	 void FindMax(int **p, int m, int n, int *pRow, int *pCol);
public:
	matrix(void);
	matrix(int r,int c);
	virtual ~matrix(void);
	void print();
	void printTranspose();
	void printColumnSum();
	void printMax();
};

