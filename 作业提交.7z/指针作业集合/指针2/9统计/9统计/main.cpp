
#include <iostream>
using namespace std;
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mystrings.h"
#include "strForCpy.h"

void main()
{
	class strForCpy strs(1);

	//int a=1;
	//int b=0;
	//int *p=&a;
	//b=*p++;
	strs.outpuStatistics();
	
	cout<<"\nend here \n";
}