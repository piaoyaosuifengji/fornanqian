#include "mystrings.h"
#include <iostream>
using namespace std;
void mystrings::check(char * s)
{
	int i;
	char c;
	for(i=0;;i++)
	{
		c=s[i];
		if(c == '\0')
			break;

		if(c<33 || c>126)
			s[i]='\0';
	}

}
mystrings::mystrings(void):count(0)
{
	//printf("�����ַ��������� \n");
	//while(1)
	//{
	//scanf("%d",&count); 
	//if(count>0 && count<20000)
	//	break;
	//else 
	//	cout<<"wrong number,input again"<<"\n";
	//}
	count=2;
	printf("�Ӽ���������%d���ַ�����ÿ����������26���ַ���û�пո� \n",count);
	
	strs=new strForCpy[count];

	//=new strForCpy;

	char input[200]={0};
	int i;
	int tmp;
	for(i=0;i<count;i++)
	{
		if(i==1)
		{
			printf("please input strings1:");
		}
		else
			printf("please input strings2:");
		cin>>input;

		check(input);
		//int lenl=strlen(input);
		tmp=strlen(input);
		if(tmp>20 || tmp <0)
		{
			cout<<"wrong string,input again"<<"\n";
			i--;
			continue;
		}
		strs[i].setstr(input);
	}
}
mystrings::mystrings(int n):count(n)
{


}

mystrings::~mystrings(void)
{
	int i;
	if(strs)
	{

			delete [] strs ;

		
		
	}
}
void mystrings::output()
{
	cout<<"��������ַ�����\n";
	int i;
	for(i=0;i<count;i++)
	{
		strs[i].outPutStr();

	}

}
int mystrings::findMaxStr(strForCpy *strs, int count)
{
	int maxPoint=0;
	int i;
	int res=0;
	for(i=0;i<count;i++)
	{
		res=strs[maxPoint].compare(&strs[i]);
		if(res==1)
			maxPoint=i;
	}
	return maxPoint;
}
void mystrings::outputMaxStr()
{
	int maxPoint=0;
	maxPoint=findMaxStr( strs,  count);
	cout<<"�����ַ���Ϊ�� \n";
	strs[maxPoint].outPutStr();

}
void mystrings::sort()
{
	//class strForCpy *p;
	//class strForCpy *q;
	class strForCpy tmp;
	int res=0;

	//ð������
	int i,j;
	for(i=count-1;i>=0;i--)
	{
		for(j=0;j<i;j++)
		{
			res=strs[j].compare(&strs[j+1]);
			if(res==1)
			{

				tmp.setstr(&strs[j]);
				(*(strs+j)).setstr(&strs[j+1]);
				(*(strs+j+1)).setstr(&tmp);

			}
		}

	}


		//res=strs[maxPoint].compare(&strs[i]);
		//if(res==1)
		//	maxPoint=i;		

	
}
void mystrings::outputSort()
{
	printf("\n******Sort Before******\n");
	this->output();
	printf("\n******Sort After******\n");
	sort();
	this->output();
}
void mystrings::insert(class strForCpy *a,class strForCpy *b)
{
	char tmp[100];
	char tmp2[50];
	int pointA=0;
	int pointB=0;
	char aa;
	char bb;
	int pForTmp=0;
	while(pointA>=0  || pointB>=0)
	{
		aa=a->getChar(pointA);
		bb=b->getChar(pointB);
		if(bb<0)
		{
			getStrByIndex(a,pointA,tmp2);
			tmp[pForTmp]='\0';
			strcat(tmp+pForTmp,tmp2);
			break;

		}
		if(aa<0)
		{
			getStrByIndex(b,pointB,tmp2);
			tmp[pForTmp]='\0';
			strcat(tmp+pForTmp,tmp2);
			break;
		}
		tmp[pForTmp++]=aa;
		tmp[pForTmp++]=bb;
		pointA++;
		pointB++;
	}
	a->setstr(tmp);
	//printf("tmp are:%s \n",tmp);
}
void  mystrings::outputInsert()
{


	mystrings::insert(&strs[0],&strs[1]);
	printf("result are:");
	strs[0].outPutStr();
}

	 void  mystrings::getStrByIndex(class strForCpy *str,int index,char *s)
{

	if(s==NULL)
		return;
	int i=0;
	//str->getStrByIndex(index,s);
	int ccc;
	int len=str->getlen();
	char c=str->getChar(index++);
	while(c > 0)
	{
		s[i++]=c;

		ccc=c=str->getChar(index++);

	}
	s[i]='\0';
}