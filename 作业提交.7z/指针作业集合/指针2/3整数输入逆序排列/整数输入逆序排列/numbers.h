#pragma once
class numbers
{

private:
	int *data;
	int count;
	void search(int *pa,int n,int *pmax,int *pflag);
	void reverse(int *d,int n);
public:
	numbers(void);
	
	void outputNumbers(void);
	~numbers(void);
	void outputMax(void);
	
	 void outputReverse(void);
};

