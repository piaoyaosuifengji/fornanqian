#pragma once
#include "mystr.h"
class strForCpy :
	public mystr
{
private :
	char *str;
	void copyStr(char *);

	void moveStr(int m,char *);
public:
	strForCpy(void);
	strForCpy(char *);
	void outPutStr();
	~strForCpy(void);
	 static char *  getStr(int len);
	 static char *  cpoyChars(char * dest,char * src,int len,int start);//��src��start������len���ַ���dest��
	int compare(class strForCpy *otherstr);
	char getChar(int pos);
	 void setstr(char *);
	 void setstr(class strForCpy *);
	  void init();
	  int getlen();
	  

	  void outpuMoveStr();
};

