#include "mystrings.h"
#include <iostream>
using namespace std;

mystrings::mystrings(void):count(0)
{
	printf("�����ַ��������� \n");
	while(1)
	{
	scanf("%d",&count); 
	if(count>0 && count<20000)
		break;
	else 
		cout<<"wrong number,input again"<<"\n";
	}

	printf("�Ӽ���������%d���ַ�����ÿ����������20���ַ���û�пո� \n",count);
	
	strs=new strForCpy[count];

	//=new strForCpy;

	char input[200]={0};
	int i;
	int tmp;
	for(i=0;i<count;i++)
	{
		cin>>input;
		tmp=strlen(input);
		if(tmp>20 || tmp <1)
		{
			cout<<"wrong string,input again"<<"\n";
			i--;
			continue;
		}
		strs[i].setstr(input);
	}
}
mystrings::mystrings(int n):count(n)
{


}

mystrings::~mystrings(void)
{
	int i;
	if(strs)
	{

			delete [] strs ;

		
		
	}
}
void mystrings::output()
{
	cout<<"��������ַ�����\n";
	int i;
	for(i=0;i<count;i++)
	{
		strs[i].outPutStr();

	}

}
int mystrings::findMaxStr(strForCpy *strs, int count)
{
	int maxPoint=0;
	int i;
	int res=0;
	for(i=0;i<count;i++)
	{
		res=strs[maxPoint].compare(&strs[i]);
		if(res==1)
			maxPoint=i;
	}
	return maxPoint;
}
void mystrings::outputMaxStr()
{
	int maxPoint=0;
	maxPoint=findMaxStr( strs,  count);
	cout<<"�����ַ���Ϊ�� \n";
	strs[maxPoint].outPutStr();

}
void mystrings::sort()
{
	//class strForCpy *p;
	//class strForCpy *q;
	class strForCpy tmp;
	int res=0;

	//ð������
	int i,j;
	for(i=count-1;i>=0;i--)
	{
		for(j=0;j<i;j++)
		{
			res=strs[j].compare(&strs[j+1]);
			if(res==1)
			{

				tmp.setstr(&strs[j]);
				(*(strs+j)).setstr(&strs[j+1]);
				(*(strs+j+1)).setstr(&tmp);

			}
		}

	}


		//res=strs[maxPoint].compare(&strs[i]);
		//if(res==1)
		//	maxPoint=i;		

	
}
void mystrings::outputSort()
{
	printf("\n******Sort Before******\n");
	this->output();
	printf("\n******Sort After******\n");
	sort();
	this->output();
}