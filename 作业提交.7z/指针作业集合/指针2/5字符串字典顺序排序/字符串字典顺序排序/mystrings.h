#pragma once
#include "strForCpy.h"
class mystrings
{

private :
	class strForCpy *strs;
	class strForCpy **strsForSort;
	 int count;

	 int findMaxStr(strForCpy *strs, int count);
	 void sort();
public:
	mystrings(void);
	~mystrings(void);
	mystrings(int n);
	void outputMaxStr();
	void output();
	void outputSort();
};

