
#include <iostream>
using namespace std;
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mystrings.h"
#include "strForCpy.h"
//void lin()
//{
//	char * inputStr;
//	
//	//inputStr=strForCpy::getStr(100);
//	//printf("��������ַ���Ϊ��%s \n",inputStr);
//	//
//
//	class mystrings  strs(5);
//}
void main()
{
	class mystrings *strs=new mystrings;
	strs->outputSort();
	cout<<"end here \n";
}