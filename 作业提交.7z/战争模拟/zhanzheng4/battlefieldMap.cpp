
#include "army.h"
#include "battlefieldMap.h"
#include <stdio.h>
#include "conio.h"
//#include <graphics.h>
#include <stdlib.h>
void mapInit(MAP * map)
{
	int i,j;
	int count=0;
	for(i=0;i<MAPSIZEH;i++)//y
	{
		for(j=0;j<MAPSIZEL;j++)//x
		{

			//map->content[j][i]=count++;
			map->content[i][j]=0;
		}

	}
	//printMAP(map);
}
void deployArray(MAP *map,ARMY * army,int tactics)//��ʿ�����𵽵�ͼ�У�ʹ�ò���tactics
{
	switch(tactics)
	{
	case 1://��ʿ�������ڵ�ͼ�Ϸ�
		deployArrayTop(map,army);
		break;
	case 2://��ʿ�������ڵ�ͼ�·�
		deployArrayDown(map,army);
		break;
	default :break;

	}

}
void deployArrayDown(MAP *map,ARMY * army)
{
	//�������ң��������±�����ͼ�ҿ�λ��
	int i,j;
	int armsTypeCount=0;
	int armsType=0;
	Point2 pos;
	soldier * sold;
	for(i=MAPSIZEH-1;i>=0;i--)//y
	{
		for(j=0;j<MAPSIZEL;j++)//x
		{
			sold= getSoldier(army,armsType,armsTypeCount);
			if(sold == NULL)
			{
				if(armsType < army->armsTypeCount)
				{
					armsType++;
					armsTypeCount=0;
					j--;
				}
				else
					return;
			}
			else
			{
				pos.x=j;
				pos.y=i;
				
				setSoldierPos(sold, pos );
				pos.x=i;
				pos.y=j;
				setMapcontent(map, pos,sold->HP);
				armsTypeCount++;
			}
		}

	}
}
void deployArrayTop(MAP *map,ARMY * army)
{
	//�������ң��������±�����ͼ�ҿ�λ��
	int i,j;
	int armsTypeCount=0;
	int armsType=0;
	Point2 pos;
	soldier * sold;
	for(i=0;i<MAPSIZEH;i++)//y
	{
		for(j=0;j<MAPSIZEL;j++)//x
		{
			sold= getSoldier(army,armsType,armsTypeCount);
			if(sold == NULL)
			{
				if(armsType < army->armsTypeCount)
				{
					armsType++;
					armsTypeCount=0;
					j--;
				}
				else
					return;
			}
			else
			{
				pos.x=j;
				pos.y=i;
				
				setSoldierPos(sold, pos );
				pos.x=i;
				pos.y=j;
			setMapcontent(map, pos,sold->HP);
				armsTypeCount++;
			}
		}

	}
}

void setMapcontent(MAP *map,Point2 pos,int flag)
{
	if(flag<0)
		flag=0;
	map->content[pos.x][pos.y]=flag;
}
int getMapcontent(MAP *map,Point2 pos)
{
	return map->content[pos.x][pos.y];
}
void printMAP(MAP *map)
{
	int i,j;
	int armsTypeCount=0;
	int armsType=0;
	Point2 pos;
	soldier * sold;
	int res;
	printf("\n");
	printf("\n");
	system("color 00");
	//system("color 0B");
  //cprintf("This is blinking\r\n");
	for(i=0;i<MAPSIZEH;i++)//y
	{
		for(j=0;j<MAPSIZEL;j++)//x
		{
				pos.x=i;
				pos.y=j;
				res=getMapcontent(map, pos);
			if( res== 0)
			{
				printf("..  ");
			}
			else
			{
				printf("%3d ",res);
				//system("color 00");
			}

		}
		printf("\n");
	}


}
int ifCouldMove(MAP *map,Point2 pos)
{
	if(pos.x < 0  || pos.x >= MAPSIZEL ||  pos.y < 0 ||  pos.y >= MAPSIZEH  )
		return 0;
	int res=(map->content)[pos.x][pos.y];
	if(res == 0)
		return 1;
	else
		return 0;
}

void prinColourtMAP(MAP *map,ARMY *red,ARMY *blue)
{
	int i,j;
	int armsTypeCount=0;
	int armsType=0;
	Point2 pos,tmp;
	soldier * sold;
	int res,res2;
	printf("\n");
	printf("\n");

	//system("color 0B");
  //cprintf("This is blinking\r\n");
	for(i=0;i<MAPSIZEH;i++)//y
	{
		for(j=0;j<MAPSIZEL;j++)//x
		{
				pos.x=i;
				pos.y=j;
				res=getMapcontent(map, pos);
				//system("color 00");
			if( res== 0)
				printf(". ");
			else
			{
				tmp.x=pos.y;
				tmp.y=pos.x;

				 //res= soldierIsHere(map,red,tmp)
				res2=soldierIsHere(map,red,tmp);
				if(res2 ==1)
				{
					//system("color 04");
					printf("* ");
				}
				else
					printf("o ");
				//	system("color 01");
				//printf("%3d ",res);
				
			}

		}
		//system("color 00");
		//system("color 0f");
		printf("\n");
	}


}