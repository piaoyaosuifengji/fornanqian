#pragma once
#ifndef POINT_H
#define POINT_H


struct Point2
{

	int x;
	int y;


};
#endif
