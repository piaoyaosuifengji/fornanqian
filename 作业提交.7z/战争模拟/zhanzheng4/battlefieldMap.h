#pragma once
#ifndef BATTLEFILED_H
#define BATTLEFILED_H
//#include "army.h"


#define MAPSIZEL  20
#define MAPSIZEH  8

typedef struct battlefieldMap
{
	int content[MAPSIZEH][MAPSIZEL];//Ĭ�����Ͻ�����Ϊ��0,0��



}MAP;
//
void mapInit(MAP *);
void deployArray(MAP *,struct army_1 * army,int tactics);
void deployArrayTop(MAP *,struct army_1 * army);
void deployArrayDown(MAP *map,struct army_1 * army);


void setMapcontent(MAP *,Point2 pos,int flag);//flag=0ʱ��ʾ���ø�λ��Ϊ��
int  getMapcontent(MAP *,Point2 pos);
void printMAP(MAP *);
void prinColourtMAP(MAP *map,struct army_1  *red,struct army_1  *blue);
int ifCouldMove(MAP *map,Point2 pos);
#endif BATTLEFILED_H