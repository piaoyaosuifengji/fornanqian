#ifndef SOLDIER_H
#define SOLDIER_H
#include "Point2.h"
#include "battlefieldMap.h"

typedef struct soldier_st
{

	int HP;
	int attack;
	int distance;
	Point2 pos;
	int type;

}soldier;
//void setSoldier(soldier * s,int hp,int attacks,int distances,Point2 pos,int types );
void printsoldierMsg(soldier *);
void setSoldier(soldier * s,int hp,int attack,int distance,Point2 pos,int types );
void setSoldier2(soldier * to,soldier * from );
void setSoldierPos(soldier * to,Point2 pos );
int attackSoldier(soldier *self,soldier * enemysoldier);//ʿ��self����enemysoldier�����������ͷ���0

int ifCouldAttack(soldier *self,soldier * enemysoldier);
void movesoldier(MAP *map,soldier *self,Point2 pos);

int  findPosCouldMove(MAP *map,soldier *self,int tactics,Point2 *result);


#endif SOLDIER_H