
//#include "battle.h"
//#include "battlefieldMap.h"
//#include "army.h"
//void armyAttack(MAP *map,ARMY *seft,ARMY *target)
//{
//
//	int i,j;
//	for(i=0;i<(seft->armsTypeCount);i++)
//	{
//		for(j=0;j<(seft->armsType[i]);j++)
//		{
//
//
//		}
//
//	}
//
//}
//void battle(MAP *map,ARMY *red,ARMY *blue)
//{


	//while(isOver(map,red ,blue) !=1)
	//{

		//�췽����
		//armyAttack(map,red ,blue);
		//�췽�ƶ�
		//armyMove(map,red ,blue);


		//�췽����
		//armyAttack(map,blue ,red);
		//�췽�ƶ�
		//armyMove(map,blue ,red);

//	}
//
//
//
//
//
//}
//
//int isOver(MAP *map,ARMY *seft,ARMY *target)
//{
//
//
//	return 1;
//}