#include "soldier.h"
#include "army.h"
#include <stdio.h>

void setSoldier(soldier * s,int hp,int attacks,int distances,Point2 pos,int types )
{
	 s->HP=hp;
	 s->attack=attacks;
	 s->distance=distances;
	 s->type=types;
	 s->pos.x=pos.x;
	 s->pos.y=pos.y;
}
void setSoldier2(soldier * to,soldier * from )
{

	setSoldier(to,from->HP,from->attack,from->distance,from->pos,from->type );
}
void printsoldierMsg(soldier *  ss)
{

	printf("	type=%d,distance=%d,attack=%d,HP=%d,x=%d,y=%d \n",ss->type,ss->distance,ss->attack,ss->HP,ss->pos.x,ss->pos.y);
}
void setSoldierPos(soldier * to,Point2 pos )
{
	to->pos.x=pos.x;
	to->pos.y=pos.y;
}

int attackSoldier(soldier *self,soldier * enemysoldier)
{
	enemysoldier->HP=enemysoldier->HP-self->attack;


	if(enemysoldier->HP<=0)
	{
		
		enemysoldier->HP=0;
		return 1;
	}
	else
		return 0;


}
int ifCouldAttack(soldier *self,soldier * enemysoldier)
{

	int res=0;
	int distance;
	int Attackdistance;
	if(enemysoldier->HP <=0)
		return 0;
	distance=(self->pos.x-enemysoldier->pos.x)*(self->pos.x-enemysoldier->pos.x)+(self->pos.y-enemysoldier->pos.y)*(self->pos.y-enemysoldier->pos.y);
	Attackdistance=self->distance  * self->distance;
	if(Attackdistance   >= distance)//��������
		return 1;

	return 0;
}
void movesoldier(MAP *map,soldier *self,Point2 pos)//x�Ǻᣬy����
{
	Point2 tmp;
	tmp.y=self->pos.x;
	tmp.x=self->pos.y;
	setMapcontent(map, tmp,0);
	(self->pos.x)=pos.x;
	(self->pos.y)=pos.y;
	tmp.y=self->pos.x;
	tmp.x=self->pos.y;
	setMapcontent(map,tmp,self->HP);//flag=0ʱ��ʾ���ø�λ��Ϊ��
}
  int  findPosCouldMove(MAP *map,soldier *self,int tactics,Point2 *result)
{
	int i,j,res;
	Point2 pos;
	switch(tactics)
	{
	case 1://�����ƶ�
		for(i=1;i<=self->distance;i++)
			{
				pos.x=self->pos.y-i;
				pos.y=self->pos.x;
				res=ifCouldMove(map, pos);
				if(res ==1)
				{
					(*result).y=pos.x;
					(*result).x=pos.y;
					return 1;

				}
			}
			break;
	case 2://�����ƶ�
		for(i=1;i<=self->distance;i++)
			{
				pos.y=self->pos.x;
				pos.x=self->pos.y+i;
				res=ifCouldMove(map, pos);
				if(res ==1)
				{
					(*result).y=pos.x;
					(*result).x=pos.y;
					return 1;

				}
			}
			break;

	default:
		break;
	}

	result=NULL;
	return 0;

}
  int soldierIsHere(MAP *map,ARMY *seft,struct Point2 pos)//�ж�pos���ĵ��ǲ���seft�ı�
  {

	int i,j;
	soldier * tmp;
	for(i=0;i<seft->armsTypeCount;i++)
	{
		for(j=0;j<(seft->armsType[i]);j++)
		{
			tmp= getSoldier(seft,i,j);
			if(tmp->pos.x == pos.x  && tmp->pos.y == pos.y )
				return 1;
		}

	}

	  return 0;
  }