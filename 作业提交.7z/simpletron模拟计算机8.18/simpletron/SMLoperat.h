void SMLread(int storeAddr,int memory[][5]);
void SMLWrite(int writeAddr,int memory[][5]);
void SMLLoad(int addr,int memory[][5],int *accumulator);
void SMLStore(int addr,int memory[][5],int *accumulator);
void SMLADD(int addr,int memory[][5],int *accumulator);
void SMLSUB(int addr,int memory[][5],int *accumulator);
void SMLDIVIDE(int addr,int memory[][5],int *accumulator);
void SMLMUL(int addr,int memory[][5],int *accumulator);

